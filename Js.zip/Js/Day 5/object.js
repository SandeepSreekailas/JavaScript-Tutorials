let students = {
    name : 'sandeep',
    age : 22,
    rollNo : 42,
    mark : 77,
    getdetails : function(){
        console.log("Student Name: " + this.name);
    },
    arr:[1,2,"hello","String"],

    //nested objects
    address:{
        landmark:'paris',
        pincode: 123,
        houseno: 10,
        gurdain:{
            name: 'angel',
            age : 52
        }
    }
};
// students.getdetails();
// console.log(students.arr[2]); // .  notation
// console.log(students["age"]); // [] notation

//update
// students.age = 23;
// console.log(students.age);

//insert in object
// students.supply = false
// console.log(students.supply)

//delete
// delete students.arr;
// console.log(students);

//iterate over object
// for(let obj in students){
//     console.log(obj + ":-" + students[obj]);
// }

// let obj = Object.keys(students);
// let i = 0;
// while(i<obj.length){
//     console.log(obj[i] + ":-" + students[obj[i]]);
//     i++;
// }


// console.log(students.address.gurdain.name);
