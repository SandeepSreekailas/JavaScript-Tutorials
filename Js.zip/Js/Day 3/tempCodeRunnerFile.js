let players = [
    { name: 'S', score: 90},
    { name: 'A', score: 40},
    { name: 'N', score: 60},
    { name: 'D', score: 50},
    { name: 'E', score: 80},
    { name: 'P', score: 100}
]