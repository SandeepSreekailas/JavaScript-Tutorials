document.write("hello world")
  


