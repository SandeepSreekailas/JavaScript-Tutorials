// console.log("print hello", "hiiiii", "iam sandeep", 22);

// let a = 10;
// var b = 20;
// const c = 30;
// console.log(a,b,c);

// Datatypes
// let a = 90.1;
// let b = "sandeep";
// let c = true;
// let d;
// let e = null;
// let f = BigInt(789456321);
// let g = Symbol("abc");

// console.log(typeof a, typeof b, typeof c, typeof d, typeof e, typeof f,  g);

// undefined and null
// let name;
// console.log(name);

// let  n = null;
// console.log(n);

// non premitive data types (Objects)
// let person = {
//     firstname : 'sandeep',
//     lastname : 's',
//     age : 22
// }
// person.age=23
// person.education="MCA";
// console.log(person)

//Arithematic Operators
// let a = 2+3;
// let b = 10-3;
// let c = 10*10;
// let d = 10/2;
// let e = 5%3;
// let f = 10**5;
// console.log(a,b,c,d,e,f)
// console.log(f);



//Assignment Operators
// let x=7;
// x+=2; // x= x+2
// x-=5;
// x*=2;
// x/=5;
// x%=7;
// x**=5;
// console.log(x)



// Comparison Operators
// console.log(3=='3');
// console.log(3!=4);
// console.log(3>3);
// console.log(3<3);
// console.log(3>=3);
// console.log(3<=3);
// console.log(3===3); // Strictly equality operator


// console.log(3=="3");
// console.log(3==="3");


// Logical operators
// And Or  Not
// console.log(3==3 || 4<3);
// console.log(4>=4 && 4>5);
// console.log(!(5<10))

//implicit type conversion :- Type coercion
// console.log(35+"hello");
// console.log(35*"hello");

//explicit type conversion :- Type casting
// let a =30;
// let s = "srttt";
// console.log(typeof s); 