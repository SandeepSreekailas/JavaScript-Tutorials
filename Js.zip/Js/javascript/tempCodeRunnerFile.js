var a = [9,8,7,3,5,1,2]
a.sort()